(function() {
    'use strict';

    angular.module("userData", ['userData.services']
    );

})();




